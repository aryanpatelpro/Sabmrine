// camkit.ts — camera presets for story-shorts-3d. Pure math (no three.js). Every preset returns a function of the ABSOLUTE frame number
// that yields the same shape story.ts uses: { pos, look, fov, roll }. Use one preset per shot inside camAt().
// Speed targets (measured on 9 Ricks Clips videos): median pan 10-32 %/s of screen width, bursts 8-17x faster, zoom 9-25 %/s, roll 0.7-2.7 deg/s.
// Our v1 drift was 4 %/s (too slow). Presets below land inside the target band (see references/04-camera-presets.md, numbers from camkit.test.ts).
export type V3 = [number, number, number];
export type Cam = { pos: V3; look: V3; fov: number; roll: number };
export type CamFn = (f: number) => Cam;
export type Common = { fov?: number; roll?: number; rollTo?: number; whipIn?: 1 | -1; whipOut?: 1 | -1 };
const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const smooth = (x: number) => { const t = clamp(x); return t * t * (3 - 2 * t); };           // ease in-out
const easeIn = (x: number) => { const t = clamp(x); return t * t; };
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const lerp3 = (a: V3, b: V3, t: number): V3 => [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];
const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
const rotY = (v: V3, rad: number): V3 => [v[0] * Math.cos(rad) + v[2] * Math.sin(rad), v[1], -v[0] * Math.sin(rad) + v[2] * Math.cos(rad)];
const deg = (d: number) => (d * Math.PI) / 180;
export const WHIP_FRAMES = 6;          // length of the swish at a whipOut / whipIn
export const WHIP_DEG = 10;            // how far the view swings during the swish (hide it with a 6-frame crossfade, XFADE in story.ts)

/** wraps a base camera with roll and the optional whip at the shot edges */
const finish = (a: number, b: number, c: Common, base: (t: number, f: number) => { pos: V3; look: V3 }, fov: number): CamFn => (f) => {
  const t = clamp((f - a) / Math.max(1, b - a));
  let { pos, look } = base(t, f);
  let yaw = 0;
  if (c.whipOut) yaw += c.whipOut * deg(WHIP_DEG) * easeIn((f - (b - WHIP_FRAMES)) / WHIP_FRAMES);
  if (c.whipIn) yaw -= c.whipIn * deg(WHIP_DEG) * easeIn(1 - (f - a) / WHIP_FRAMES);
  if (yaw !== 0) look = add(pos, rotY(sub(look, pos), yaw));
  return { pos, look, fov, roll: lerp(c.roll ?? 0, c.rollTo ?? c.roll ?? 0, smooth(t)) };
};

/** Orbit around a point. degrees 10-18 = the "drift" (calm), 30-60 = energetic. rise = camera height gain in metres. */
export const orbit = (a: number, b: number, o: Common & { pos: V3; look: V3; degrees?: number; rise?: number }): CamFn => {
  const d0 = sub(o.pos, o.look), deg0 = o.degrees ?? 16;
  return finish(a, b, o, (t) => { const r = rotY(d0, deg(deg0) * smooth(t)); return { pos: [o.look[0] + r[0], o.pos[1] + (o.rise ?? 0) * smooth(t), o.look[2] + r[2]], look: o.look }; }, o.fov ?? 40);
};
/** Push in (factor < 1, e.g. 0.6 = end at 60% of the start distance) or pull out (factor > 1). */
export const push = (a: number, b: number, o: Common & { pos: V3; look: V3; factor?: number; sweepDeg?: number }): CamFn => {
  const d0 = sub(o.pos, o.look), k = o.factor ?? 0.6;
  return finish(a, b, o, (t) => { const s = lerp(1, k, smooth(t)); const r = rotY([d0[0] * s, d0[1] * s, d0[2] * s], deg(o.sweepDeg ?? 0) * smooth(t)); return { pos: add(o.look, r), look: o.look }; }, o.fov ?? 40);
};
/** Camera stays, view sweeps from lookA to lookB (pan / tilt / tilt-through into the next scene). */
export const pan = (a: number, b: number, o: Common & { pos: V3; lookA: V3; lookB: V3 }): CamFn =>
  finish(a, b, o, (t) => ({ pos: o.pos, look: lerp3(o.lookA, o.lookB, smooth(t)) }), o.fov ?? 40);
/** Camera and look point travel together along a line (side-tracking shot). */
export const track = (a: number, b: number, o: Common & { posA: V3; posB: V3; lookOffset: V3 }): CamFn =>
  finish(a, b, o, (t) => { const p = lerp3(o.posA, o.posB, smooth(t)); return { pos: p, look: add(p, o.lookOffset) }; }, o.fov ?? 40);
/** Crane: camera rises (or sinks with negative rise) while looking at one point. */
export const crane = (a: number, b: number, o: Common & { pos: V3; look: V3; rise: number; pull?: number }): CamFn => {
  const d0 = sub(o.pos, o.look);
  return finish(a, b, o, (t) => { const s = smooth(t); const k = lerp(1, o.pull ?? 1, s); return { pos: [o.look[0] + d0[0] * k, o.pos[1] + o.rise * s, o.look[2] + d0[2] * k], look: o.look }; }, o.fov ?? 40);
};
/** Top-down / aerial: starts high looking straight down, descends and spins the picture (roll). */
export const topDown = (a: number, b: number, o: Common & { center: V3; height?: number; descend?: number; spinDeg?: number }): CamFn => {
  const h = o.height ?? 24, dsc = o.descend ?? 9;
  return finish(a, b, { ...o, roll: 0, rollTo: deg(o.spinDeg ?? 8) }, (t) => ({ pos: [o.center[0] + 0.01, h - dsc * smooth(t), o.center[2] + 0.01], look: o.center }), o.fov ?? 44);
};
/** POV / handheld: near-static with small deterministic bob (use for in-vehicle or "someone is looking" shots). */
export const handheld = (a: number, b: number, o: Common & { pos: V3; look: V3; amp?: number }): CamFn => {
  const A = o.amp ?? 0.05;
  return finish(a, b, o, (_t, f) => ({ pos: [o.pos[0] + A * Math.sin(f * 0.21), o.pos[1] + A * Math.sin(f * 0.33 + 1), o.pos[2]], look: [o.look[0] + A * 0.6 * Math.sin(f * 0.17 + 2), o.look[1], o.look[2]] }), o.fov ?? 52);
};
export const PRESETS = { orbit, push, pan, track, crane, topDown, handheld };
export type PresetName = keyof typeof PRESETS;
