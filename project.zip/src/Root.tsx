import React from "react";
import { Composition } from "remotion";
import { Video, SUBMARINE_FRAMES } from "./videos/video/video";
export const RemotionRoot: React.FC = () => (
  <Composition id="U1206Short" component={Video} durationInFrames={SUBMARINE_FRAMES} fps={30} width={1080} height={1920} />
);
