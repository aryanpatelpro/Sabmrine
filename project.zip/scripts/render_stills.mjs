// render_stills.mjs <compositionId> <outDir> <frames,comma> [light]  — look-dev/preview stills (jpeg, half buffer). Sandbox: BROWSER_EXE=/tmp/chromium (software GL).
// On a normal machine leave BROWSER_EXE unset. Prints one line per still. Run DETACHED in the sandbox (tool calls die after 300 s).
import { bundle } from "@remotion/bundler";
import { renderStill, selectComposition } from "@remotion/renderer";
import path from "node:path";
const [compId, outDir, frames, light] = process.argv.slice(2);
const browserExecutable = process.env.BROWSER_EXE || undefined, chromiumOptions = { gl: "swiftshader" };
const inputProps = { post: { dpr: 0.5, ...(light ? { forceLight: light } : {}) } };
const serveUrl = await bundle({ entryPoint: path.resolve("src/index.ts"), publicDir: path.resolve("public") });
const composition = await selectComposition({ serveUrl, id: compId, browserExecutable, chromiumOptions, inputProps });
for (const f of frames.split(",").map(Number)) {
  await renderStill({ composition, serveUrl, frame: f, output: `${outDir}/f${String(f).padStart(4, "0")}.jpg`, imageFormat: "jpeg", browserExecutable, chromiumOptions, inputProps, timeoutInMilliseconds: 240000, scale: 0.5 });
  console.log("still", f);
}
