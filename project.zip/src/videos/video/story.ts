// Timeline of "The Toilet That Sank a Submarine" (U-1206, North Sea off Scotland, April 1945):
// 23 shots timed at 30 fps (1952 frames = 65.06 s) from beats.json, using camkit presets exclusively.
// Exports match the reference-implementation contract (FPS, TOTAL, D0, TANK_POS, TANK_R, TANK_H, KITCHEN,
// SHOTS, XFADE, FLASH_AT, shotAt, layersAt, floodState, camAt, dofAt, FOREGROUND).

import { orbit, push, pan, track, crane, topDown, handheld, Cam, CamFn, V3 } from "./camkit";

export type { V3, Cam };
export const FPS = 30;
export const TOTAL = 1952; // 65.06 s @ 30 fps (from beats.json)
export const D0 = 2.0; // submarine deck / floor elevation (m)
export const TANK_POS: V3 = [0, D0, 12]; // submerged hull / airlock manifold center
export const TANK_R = 4.2;
export const TANK_H = 8.4;
export const KITCHEN: V3 = [65, D0, -60]; // mess-table shaken soda-bottle analogy set (Shot 19)

export const clamp01 = (x: number) => Math.max(0, Math.min(1, x));
export const smooth = (x: number) => {
  const u = clamp01(x);
  return u * u * (3 - 2 * u);
};
export const easeOut = (u: number) => 1 - (1 - clamp01(u)) ** 4;

const lin = (pts: [number, number][], x: number) => {
  if (x <= pts[0][0]) return pts[0][1];
  for (let i = 1; i < pts.length; i++) {
    if (x <= pts[i][0]) {
      const [x0, y0] = pts[i - 1], [x1, y1] = pts[i];
      return y0 + ((y1 - y0) * (x - x0)) / (x1 - x0);
    }
  }
  return pts[pts.length - 1][1];
};

// ---------------- story physics (tau = story time in seconds) ----------------
export const SNAP = 36.90;   // Shot 14: outer sea valve opened -> freezing seawater blasts back through bowl (frame 1107)
export const SURGE0 = 37.20; // Seawater floods toilet compartment floor
export const DROP1 = 54.35;  // Shot 21: salty water hits giant lead-acid batteries -> deadly chlorine gas (frame 1630)
export const FREEZE0 = 60.33; // Shot 23: submarine forced to surface under British bombers & sinks (frame 1810)

/** Pressure / valve strain bulge (m) before outer sea valve opens */
export const tankBulge = (tau: number) =>
  lin([[0, 0], [19.8, 0.08], [31.2, 0.22], [34.2, 0.48], [SNAP, 0.75], [SNAP + 0.5, 0.15]], tau);

/** Seawater / chlorine gas front Z progression */
export const waveFrontZ = (tau: number) =>
  lin([[0, 10], [SURGE0, 6], [41.5, -2], [DROP1, -6], [FREEZE0, -14], [65.06, -18]], tau);

/** Seawater jet & chlorine plume height (m) */
export const waveHeight = (tau: number) =>
  lin([[0, 0], [SNAP, 0], [SNAP + 0.4, 2.6], [41.5, 1.8], [DROP1, 2.2], [57.5, 3.1], [FREEZE0, 1.4], [65.06, 0.8]], tau);

/** Chlorine gas density / toxicity index (0 = clear air, 1 = dense green chlorine cloud) */
export const viscosityAt = (tau: number) =>
  lin([[0, 0.0], [SURGE0, 0.1], [51.6, 0.25], [DROP1, 0.75], [57.57, 1.0], [65.06, 0.9]], tau);

export type FloodState = {
  bulge: number;
  ruptured: boolean;
  peel: number;      // 0..1 outer valve open / hull sinking tilt
  waveZ: number;     // leading edge Z of water/gas
  waveH: number;     // jet / gas plume height (m)
  viscosity: number; // 0..1 chlorine gas concentration
};

// ---------------- shots (exact frames from beats.json) ----------------
export type Light = "day" | "golden" | "night" | "dusk";
export type LocationId = "toilet_head" | "sub_corridor" | "ocean_abyss" | "battery_room" | "north_sea_sky";
export type Crowd =
  | "hook_lock"
  | "valves_cu"
  | "corridor_knock"
  | "captain_smug"
  | "abyss_aerial"
  | "septic_cutaway"
  | "german_blueprint"
  | "air_shoot"
  | "specialist_rule"
  | "manual_study"
  | "day_eight"
  | "wheel_stuck"
  | "wrong_valve"
  | "geyser_blast"
  | "captain_scream"
  | "firehose_cutaway"
  | "airlock_top"
  | "airlock_bottom"
  | "soda_analogy"
  | "battery_grate"
  | "chlorine_boil"
  | "gas_pov"
  | "surface_sinking";

export type ShotDef = {
  id: number;
  a: number;
  b: number;
  light: Light;
  location: LocationId;
  crowd: Crowd;
  tau: (t: number) => number;
  towns?: boolean;
};

export const SHOTS: ShotDef[] = [
  { id: 1,  a: 0,    b: 87,   light: "dusk",   location: "toilet_head",   crowd: "hook_lock",        tau: (t) => t },
  { id: 2,  a: 87,   b: 166,  light: "dusk",   location: "toilet_head",   crowd: "valves_cu",        tau: (t) => t },
  { id: 3,  a: 166,  b: 284,  light: "dusk",   location: "sub_corridor",  crowd: "corridor_knock",   tau: (t) => t },
  { id: 4,  a: 284,  b: 348,  light: "dusk",   location: "toilet_head",   crowd: "captain_smug",     tau: (t) => t },
  { id: 5,  a: 348,  b: 411,  light: "night",  location: "ocean_abyss",   crowd: "abyss_aerial",     tau: (t) => t },
  { id: 6,  a: 411,  b: 494,  light: "night",  location: "ocean_abyss",   crowd: "septic_cutaway",   tau: (t) => t },
  { id: 7,  a: 494,  b: 594,  light: "golden", location: "sub_corridor",  crowd: "german_blueprint", tau: (t) => t },
  { id: 8,  a: 594,  b: 668,  light: "night",  location: "ocean_abyss",   crowd: "air_shoot",        tau: (t) => t },
  { id: 9,  a: 668,  b: 723,  light: "golden", location: "sub_corridor",  crowd: "specialist_rule",  tau: (t) => t },
  { id: 10, a: 723,  b: 822,  light: "golden", location: "sub_corridor",  crowd: "manual_study",     tau: (t) => t },
  { id: 11, a: 822,  b: 937,  light: "dusk",   location: "toilet_head",   crowd: "day_eight",        tau: (t) => t },
  { id: 12, a: 937,  b: 1026, light: "dusk",   location: "toilet_head",   crowd: "wheel_stuck",      tau: (t) => t },
  { id: 13, a: 1026, b: 1107, light: "dusk",   location: "toilet_head",   crowd: "wrong_valve",      tau: (t) => t },
  { id: 14, a: 1107, b: 1182, light: "night",  location: "toilet_head",   crowd: "geyser_blast",     tau: (t) => t },
  { id: 15, a: 1182, b: 1247, light: "night",  location: "toilet_head",   crowd: "captain_scream",   tau: (t) => t },
  { id: 16, a: 1247, b: 1356, light: "night",  location: "ocean_abyss",   crowd: "firehose_cutaway", tau: (t) => t },
  { id: 17, a: 1356, b: 1437, light: "golden", location: "toilet_head",   crowd: "airlock_top",      tau: (t) => t },
  { id: 18, a: 1437, b: 1493, light: "golden", location: "toilet_head",   crowd: "airlock_bottom",   tau: (t) => t },
  { id: 19, a: 1493, b: 1548, light: "golden", location: "sub_corridor",  crowd: "soda_analogy",     tau: (t) => t },
  { id: 20, a: 1548, b: 1630, light: "night",  location: "battery_room",  crowd: "battery_grate",    tau: (t) => t },
  { id: 21, a: 1630, b: 1727, light: "night",  location: "battery_room",  crowd: "chlorine_boil",    tau: (t) => t },
  { id: 22, a: 1727, b: 1810, light: "night",  location: "sub_corridor",  crowd: "gas_pov",          tau: (t) => t },
  { id: 23, a: 1810, b: TOTAL,light: "day",    location: "north_sea_sky", crowd: "surface_sinking",  tau: (t) => t, towns: true },
];

/** Crossfades (frames): 6 frames on every whip transition, 8 frames on dissolves */
export const XFADE: Record<number, number> = {
  2: 8,
  3: 6,
  4: 8,
  5: 6,
  6: 8,
  7: 8,
  8: 6,
  9: 8,
  10: 6,
  11: 8,
  12: 8,
  13: 6,
  14: 6,
  16: 6,
  17: 8,
  18: 8,
  19: 8,
  20: 6,
  21: 8,
  23: 6,
};
export const FLASH_AT = 1107; // 4-frame impact flash when outer sea valve blasts open

export const shotAt = (f: number) => SHOTS.find((s) => f >= s.a && f < s.b) ?? SHOTS[SHOTS.length - 1];

export const layersAt = (f: number): { id: number; alpha: number }[] => {
  for (const s of SHOTS) {
    const x = XFADE[s.id];
    if (x && f >= s.a - x / 2 && f < s.a + x / 2) {
      return [
        { id: s.id - 1, alpha: 1 },
        { id: s.id, alpha: (f - (s.a - x / 2) + 1) / (x + 1) },
      ];
    }
  }
  return [{ id: shotAt(f).id, alpha: 1 }];
};

export const floodState = (id: number, t: number): FloodState => {
  const s = SHOTS[id - 1];
  const tau = s.tau(t);
  if (id === 17 || id === 18 || id === 19) {
    return { bulge: 0.1, ruptured: false, peel: 0, waveZ: 10, waveH: 0, viscosity: 0 };
  }
  const ruptured = tau >= SNAP;
  return {
    bulge: tankBulge(tau),
    ruptured,
    peel: ruptured ? easeOut((tau - SNAP) / 0.8) : 0,
    waveZ: waveFrontZ(tau),
    waveH: waveHeight(tau),
    viscosity: viscosityAt(tau),
  };
};

// ---------------- camera presets (camkit.ts only) ----------------
// Every camera stays well above floor level (D0 = 2.0 m) and outside any moving water/hull volumes.
const CAM: Record<number, CamFn> = {
  1:  push(0,    87,   { pos: [0.6, D0 + 1.6, -9.5],  look: [0.0, D0 + 1.5, -5.0], factor: 0.62, fov: 38, roll: -0.02, rollTo: 0.02 }),
  2:  orbit(87,  166,  { pos: [1.4, D0 + 1.8, -7.8],  look: [0.0, D0 + 1.7, -4.8], degrees: 18, rise: 0.4, fov: 36, whipOut: 1 }),
  3:  pan(166,   284,  { pos: [-1.8, D0 + 1.6, -11.0], lookA: [-0.8, D0 + 1.5, -5.2], lookB: [0.6, D0 + 1.5, -5.0], fov: 40, roll: 0.015, whipIn: -1 }),
  4:  push(284,  348,  { pos: [-0.4, D0 + 1.65, -8.2], look: [0.0, D0 + 1.6, -5.0], factor: 0.65, sweepDeg: 8, fov: 36, whipOut: 1 }),
  5:  topDown(348, 411, { center: [0.0, D0 + 1.0, 12.0], height: 26, descend: 9, spinDeg: 9, fov: 44, whipIn: -1 }),
  6:  track(411, 494,  { posA: [-6.0, D0 + 2.5, 0.0], posB: [4.0, D0 + 2.5, 0.0], lookOffset: [0.0, -0.8, 12.0], fov: 42 }),
  7:  crane(494, 594,  { pos: [3.5, D0 + 0.8, -12.5], look: [0.0, D0 + 1.6, -4.5], rise: 3.2, pull: 1.15, fov: 42, rollTo: -0.02 }),
  8:  push(594,  668,  { pos: [4.2, D0 + 1.4, 4.0],   look: [0.0, D0 + 1.2, 12.0], factor: 0.58, sweepDeg: 10, fov: 38 }),
  9:  orbit(668, 723,  { pos: [1.1, D0 + 1.65, -8.5], look: [0.0, D0 + 1.6, -5.0], degrees: 16, rise: 0.3, fov: 36, whipOut: 1 }),
  10: track(723, 822,  { posA: [-2.2, D0 + 1.6, -10.5], posB: [2.2, D0 + 1.6, -10.5], lookOffset: [0.0, -0.1, 5.5], fov: 40, whipIn: -1 }),
  11: orbit(822, 937,  { pos: [2.4, D0 + 1.9, -10.5], look: [0.0, D0 + 1.5, -5.0], degrees: 24, rise: 0.6, fov: 40, roll: 0.02 }),
  12: handheld(937, 1026, { pos: [0.5, D0 + 1.6, -8.8], look: [0.0, D0 + 1.5, -5.0], amp: 0.05, fov: 38, whipOut: 1 }),
  13: push(1026, 1107, { pos: [0.9, D0 + 1.7, -7.8],  look: [0.2, D0 + 1.6, -4.8], factor: 0.48, sweepDeg: 12, fov: 36, whipIn: -1, whipOut: 1 }),
  14: orbit(1107, 1182, { pos: [-1.8, D0 + 3.2, -9.2], look: [0.0, D0 + 1.8, -5.0], degrees: 38, rise: 1.2, fov: 42, roll: -0.03, whipIn: -1 }),
  15: push(1182, 1247, { pos: [0.3, D0 + 2.8, -8.0],  look: [0.0, D0 + 1.8, -5.0], factor: 0.52, fov: 36, whipOut: 1 }),
  16: crane(1247, 1356, { pos: [8.5, D0 + 4.8, -2.0], look: [0.0, D0 + 1.5, 12.0], rise: -1.6, pull: 0.78, fov: 42, whipIn: -1 }),
  17: pan(1356,  1437, { pos: [0.0, D0 + 1.7, -8.4],  lookA: [-0.5, D0 + 2.0, -4.8], lookB: [0.5, D0 + 1.2, -4.8], fov: 36 }),
  18: push(1437, 1493, { pos: [1.2, D0 + 1.5, -8.2],  look: [0.0, D0 + 1.3, -4.8], factor: 0.6, sweepDeg: 8, fov: 38 }),
  19: orbit(1493, 1548, { pos: [KITCHEN[0] + 0.8, D0 + 1.6, KITCHEN[2] - 5.5], look: [KITCHEN[0], D0 + 1.4, KITCHEN[2]], degrees: 22, rise: 0.5, fov: 38, whipOut: 1 }),
  20: crane(1548, 1630, { pos: [2.2, D0 + 3.6, -11.5], look: [0.0, D0 + 1.2, -5.0], rise: -1.4, pull: 0.85, fov: 40, whipIn: -1 }),
  21: push(1630, 1727, { pos: [-1.2, D0 + 2.8, -8.5], look: [0.0, D0 + 1.5, -5.0], factor: 0.55, sweepDeg: 10, fov: 38, roll: 0.025 }),
  22: handheld(1727, 1810, { pos: [0.0, D0 + 3.4, -12.0], look: [0.0, D0 + 2.0, -5.0], amp: 0.06, fov: 48, whipOut: 1 }),
  23: crane(1810, TOTAL, { pos: [3.0, D0 + 2.4, -16.0], look: [0.0, D0 + 1.2, 10.0], rise: 8.5, pull: 1.35, fov: 44, whipIn: -1 }),
};

export const camAt = (id: number, f: number): Cam => (CAM[id] ?? CAM[1])(f);

// ---------------- lens: depth of field + foreground framing ----------------
export type Dof = { f: number; dur?: number; cInf: number; focus?: (f: number) => V3 };
export const DOF: Dof[] = [
  { f: 0,    cInf: 13, focus: () => [0, D0 + 1.5, -5.0] },
  { f: 87,   cInf: 15, focus: () => [0, D0 + 1.7, -4.8] },
  { f: 166,  cInf: 11, focus: () => [0, D0 + 1.5, -5.0] },
  { f: 284,  cInf: 15, focus: () => [0, D0 + 1.6, -5.0] },
  { f: 348,  cInf: 0 },
  { f: 411,  cInf: 8,  focus: () => [0, D0 + 1.5, 12.0] },
  { f: 494,  cInf: 10, focus: () => [0, D0 + 1.6, -4.5] },
  { f: 594,  cInf: 14, focus: () => [0, D0 + 1.2, 12.0] },
  { f: 668,  cInf: 15, focus: () => [0, D0 + 1.6, -5.0] },
  { f: 723,  cInf: 11, focus: () => [0, D0 + 1.5, -5.0] },
  { f: 822,  cInf: 9,  focus: () => [0, D0 + 1.5, -5.0] },
  { f: 937,  cInf: 13, focus: () => [0, D0 + 1.5, -5.0] },
  { f: 1026, cInf: 15, focus: () => [0.2, D0 + 1.6, -4.8] },
  { f: 1107, cInf: 12, focus: () => [0, D0 + 1.8, -5.0] },
  { f: 1182, cInf: 15, focus: () => [0, D0 + 1.8, -5.0] },
  { f: 1247, cInf: 6 },
  { f: 1356, cInf: 14, focus: () => [0, D0 + 1.5, -4.8] },
  { f: 1493, cInf: 12, focus: () => [KITCHEN[0], D0 + 1.4, KITCHEN[2]] },
  { f: 1548, cInf: 11, focus: () => [0, D0 + 1.2, -5.0] },
  { f: 1630, cInf: 14, focus: () => [0, D0 + 1.5, -5.0] },
  { f: 1727, cInf: 10, focus: () => [0, D0 + 2.0, -5.0] },
  { f: 1810, cInf: 0 },
];

export const dofAt = (f: number) => {
  let i = 0;
  while (i + 1 < DOF.length && f >= DOF[i + 1].f) i++;
  const d = DOF[i], p = DOF[Math.max(0, i - 1)];
  const k = d.dur ? Math.min(1, (f - d.f) / d.dur) : 1;
  return { cInf: p.cInf + (d.cInf - p.cInf) * k, focus: d.focus };
};

export type Fg = { a: number; b: number; kit: string; pos: V3; s?: number; yaw?: number };
export const FOREGROUND: Fg[] = [
  { a: 166,  b: 284,  kit: "cart",              pos: [-2.4, D0, -7.8], s: 0.75, yaw: 0.4 },
  { a: 723,  b: 822,  kit: "cart",              pos: [-2.6, D0, -7.6], s: 0.75, yaw: -0.3 },
  { a: 1493, b: 1548, kit: "plant_bushDetailed", pos: [KITCHEN[0] - 0.9, D0, KITCHEN[2] - 3.4], s: 1.0, yaw: 0.3 },
  { a: 1548, b: 1727, kit: "cart",              pos: [2.1, D0, -7.5], s: 0.8, yaw: 0.5 },
];
