// 3D world for "The Toilet That Sank a Submarine" (U-1206, North Sea off Scotland, April 1945):
// 5 distinct sets switched per shot:
//   1. toilet_head   — cramped U-boat forward WC with steel bowl, two-door airlock pipe, and brass valve rack
//   2. sub_corridor  — riveted U-boat pressure hull corridor, bulkhead hatch door, and periscope column
//   3. ocean_abyss   — 200 ft underwater North Sea exterior & cutaway pressure hull with glowing HDR lamps
//   4. battery_room  — under-floor lead-acid battery bank beneath open steel floor grating
//   5. north_sea_sky — stormy North Sea surface off Scotland, sinking U-1206 stern, yellow rubber rafts, RAF bomber
// Plus the golden-hour mess table at KITCHEN (65, D0, -60) for Shot 19's shaken soda-bottle analogy.

import * as THREE from "three";
import { getInputProps } from "remotion";
import { LIGHTS, LOOK, LightPreset, forcedLight } from "./lights";
import { TONE, CHAR, twoTone, untone } from "./shade";
import { NOINK } from "./ink";
import { Batch, V, lam, house, boxGeo } from "./build";
import { ctex, rep, cobbleHD, stoneHD, cloudHD } from "./paint";
import { Pool, Actor, Fx, stage } from "./cast";
import { FPS, D0, KITCHEN, SHOTS, FOREGROUND, camAt, floodState, FloodState, ShotDef } from "./story";

export const PALETTE = {
  hullSteel: "#4a5462",
  innerBulkhead: "#687482",
  brassValve: "#e0b242",
  dangerRed: "#c93838",
  porcelainBowl: "#dce4ec",
  seaDeep: "#1d4e78",
  chlorineGreen: "#52d45e",
  raftYellow: "#f0b832",
  batteryLead: "#2d333b",
};

const steelTex = () => ctex("subSteelRivets", 1024, 512, (g, r) => {
  g.fillStyle = "#626c7a"; g.fillRect(0, 0, 1024, 512);
  const PW = 128, PH = 128;
  for (let row = 0; row < 4; row++) for (let col = 0; col < 8; col++) {
    const v = 0.92 + 0.16 * r();
    g.fillStyle = `rgb(${Math.round(98 * v)},${Math.round(108 * v)},${Math.round(122 * v)})`;
    g.fillRect(col * PW, row * PH, PW, PH);
  }
  g.strokeStyle = "rgba(25,28,36,0.85)"; g.lineWidth = 5;
  for (let i = 0; i <= 8; i++) { g.beginPath(); g.moveTo(i * PW, 0); g.lineTo(i * PW, 512); g.stroke(); }
  for (let j = 0; j <= 4; j++) { g.beginPath(); g.moveTo(0, j * PH); g.lineTo(1024, j * PH); g.stroke(); }
  g.fillStyle = "#252830";
  for (let j = 0; j <= 4; j++) for (let i = 0; i < 48; i++) {
    const x = (i + 0.5) * (1024 / 48), y = j * PH;
    for (const dy of [-10, 10]) { g.beginPath(); g.arc(x, y + dy, 3.0, 0, 7); g.fill(); }
  }
});

const discTex = () => ctex("sunDisc", 128, 128, (g) => {
  const gr = g.createRadialGradient(64, 64, 58, 64, 64, 64);
  gr.addColorStop(0, "rgba(255,255,255,1)"); gr.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = gr; g.fillRect(0, 0, 128, 128);
});

const haloTex = () => ctex("sunHalo", 256, 256, (g) => {
  const im = g.createImageData(256, 256);
  for (let y = 0; y < 256; y++) for (let x = 0; x < 256; x++) {
    const u = Math.hypot(x - 127.5, y - 127.5) / 128;
    const a = (0.55 * Math.exp(-((u / 0.25) ** 2)) + 0.35 * Math.exp(-((u / 0.6) ** 2))) * (1 - Math.min(1, Math.max(0, (u - 0.8) / 0.2)));
    const i = (y * 256 + x) * 4;
    im.data[i] = im.data[i + 1] = im.data[i + 2] = 255; im.data[i + 3] = Math.round(255 * Math.min(1, a));
  }
  g.putImageData(im, 0, 0);
});

const flat = (color: string, extra: THREE.MeshLambertMaterialParameters = {}) => twoTone(new THREE.MeshLambertMaterial({ color, ...extra }));

export class MolassesWorld {
  root = new THREE.Group();
  private setToilet = new THREE.Group();
  private setCorridor = new THREE.Group();
  private setAbyss = new THREE.Group();
  private setBattery = new THREE.Group();
  private setSurface = new THREE.Group();
  private valveWheels: THREE.Mesh[] = [];
  private geyserJet: THREE.Mesh;
  private chlorineFogMesh: THREE.Mesh;
  private sinkingSubGroup = new THREE.Group();
  private bomberGroup = new THREE.Group();
  private raftGroup = new THREE.Group();

  private pool = new Pool(); private actors: Actor[] = []; private fxs: Fx[] = [];
  private hemi: THREE.HemisphereLight; private sun: THREE.DirectionalLight; private fill: THREE.DirectionalLight;
  private sky: THREE.Mesh; private skyMat: THREE.ShaderMaterial;
  private fog = new THREE.Fog("#bccbec", 25, 420);
  private sunDisc: THREE.Sprite; private sunHalo: THREE.Sprite;
  private sunCache = new Map<number, THREE.Vector3>();
  private cloudMaps: Record<"day" | "golden" | "night" | "dusk", THREE.Texture[]>; private clouds: THREE.Mesh[] = [];
  private fgs: { o: THREE.Object3D; a: number; b: number }[] = [];
  private frustum = new THREE.Frustum(); private m4 = new THREE.Matrix4(); private v = new THREE.Vector3(); private sph = new THREE.Sphere();

  constructor() {
    const R = this.root;
    // ---- sky + light rig (skill locked) ----
    this.skyMat = new THREE.ShaderMaterial({
      uniforms: { c0: { value: new THREE.Color() }, c1: { value: new THREE.Color() }, c2: { value: new THREE.Color() }, c3: { value: new THREE.Color() }, c4: { value: new THREE.Color() }, e: { value: new THREE.Vector4() } },
      vertexShader: "varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }",
      fragmentShader: `uniform vec3 c0, c1, c2, c3, c4; uniform vec4 e; varying vec3 vP;
        void main(){ float el = asin(clamp(normalize(vP).y, -1.0, 1.0));
          vec3 c = mix(c0, c1, smoothstep(0.0, e.x, el));
          c = mix(c, c2, smoothstep(e.x, e.y, el));
          c = mix(c, c3, smoothstep(e.y, e.z, el));
          c = mix(c, c4, smoothstep(e.z, e.w, el));
          gl_FragColor = vec4(c, 1.0); }`,
      side: THREE.BackSide, depthWrite: false, fog: false,
    });
    this.sky = new THREE.Mesh(new THREE.SphereGeometry(1100, 48, 24), this.skyMat);
    this.sky.renderOrder = -1; this.sky.frustumCulled = false; this.sky.layers.set(NOINK); R.add(this.sky);
    this.sunDisc = new THREE.Sprite(new THREE.SpriteMaterial({ map: discTex(), color: new THREE.Color(6.0, 4.4, 2.4), fog: false, depthWrite: false }));
    this.sunHalo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex(), color: new THREE.Color(1, 1, 1), fog: false, depthWrite: false, depthTest: true, transparent: true, blending: THREE.AdditiveBlending }));
    this.sunDisc.renderOrder = -0.5; this.sunHalo.renderOrder = 5;
    for (const m of [this.sunDisc, this.sunHalo]) { m.frustumCulled = false; m.layers.set(NOINK); R.add(m); }
    this.hemi = new THREE.HemisphereLight("#cfe6ff", "#6c5c8c", 1.1);
    this.sun = new THREE.DirectionalLight("#fff0d6", 2.6);
    this.sun.castShadow = true; { const sm = (getInputProps() as { post?: { shadow?: number } }).post?.shadow ?? 2048; this.sun.shadow.mapSize.set(sm, sm); }
    this.fill = new THREE.DirectionalLight("#9fb8ff", 0.35);
    R.add(this.hemi, this.sun, this.sun.target, this.fill, this.fill.target);
    this.cloudMaps = {
      day: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.day.cloud)),
      golden: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.golden.cloud)),
      night: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.night.cloud)),
      dusk: [0, 1, 2, 3].map((k) => cloudHD(k, LOOK.dusk.cloud)),
    };
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2 + 0.3, d = 620 + (i % 3) * 60;
      const m = new THREE.Mesh(new THREE.PlaneGeometry(1, 1), new THREE.MeshBasicMaterial({ map: this.cloudMaps.day[i % 4], color: new THREE.Color(1.1, 1.1, 1.1), transparent: true, depthWrite: false, fog: false }));
      const w = 130 + (i % 4) * 30;
      m.position.set(Math.cos(a) * d, 120 + (i % 4) * 38, Math.sin(a) * d); m.scale.set(w, w / 2, 1); m.layers.set(NOINK);
      this.clouds.push(m); R.add(m);
    }

    // Shared materials
    const steelMat = lam("subSteel", () => ({ map: rep(steelTex(), 4, 2), color: "#8592a2" }));
    const bulkheadMat = flat(PALETTE.innerBulkhead);
    const brassMat = twoTone(new THREE.MeshPhongMaterial({ color: PALETTE.brassValve, specular: "#fff0b8", shininess: 65 }), 0.25);
    const redMat = flat(PALETTE.dangerRed);
    const pipeMat = twoTone(new THREE.MeshPhongMaterial({ color: "#434c58", specular: "#9aa4b0", shininess: 50 }), 0.2);
    const floorMat = lam("subFloor", () => ({ map: rep(cobbleHD(), 8, 8), color: "#68707a" }));
    // HDR Bloom materials on NOINK layer (references/05-look-presets.md glow trick)
    const warmGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.2, 2.3, 1.1) });
    const redGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(3.6, 0.7, 0.5) });
    const greenGlow = new THREE.MeshBasicMaterial({ color: new THREE.Color(0.8, 3.1, 1.1) });

    const addLamp = (parent: THREE.Group, x: number, y: number, z: number, mat = warmGlow) => {
      const cage = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.18, 0.12, 12), pipeMat);
      cage.position.set(x, y + 0.08, z); parent.add(cage);
      const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.14, 14, 10), mat);
      bulb.position.set(x, y, z); bulb.layers.set(NOINK); parent.add(bulb);
    };

    // =========================================================================
    // SET 1: toilet_head (cramped forward WC with steel bowl, airlock pipe & brass valve wheels)
    // =========================================================================
    {
      const G = this.setToilet;
      const floor = new THREE.Mesh(new THREE.BoxGeometry(10, 0.2, 12), floorMat);
      floor.position.set(0, D0 - 0.1, -5.0); floor.receiveShadow = true; G.add(floor);
      const backWall = new THREE.Mesh(new THREE.BoxGeometry(8.5, 4.8, 0.35), steelMat);
      backWall.position.set(0, D0 + 2.4, -3.6); backWall.receiveShadow = true; G.add(backWall);
      for (const sx of [-1, 1]) {
        const sw = new THREE.Mesh(new THREE.BoxGeometry(0.35, 4.8, 8.0), bulkheadMat);
        sw.position.set(sx * 3.8, D0 + 2.4, -5.8); sw.receiveShadow = true; G.add(sw);
        // Curved U-boat pressure hull ribs
        for (let z = -8.5; z <= -3.8; z += 1.5) {
          const rib = new THREE.Mesh(new THREE.BoxGeometry(0.22, 4.6, 0.22), pipeMat);
          rib.position.set(sx * 3.55, D0 + 2.3, z); G.add(rib);
        }
      }
      // High-pressure steel toilet bowl & two-door airlock chamber cylinder
      const ped = new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.44, 0.55, 20), flat(PALETTE.porcelainBowl));
      ped.position.set(0.0, D0 + 0.28, -4.4); ped.castShadow = true; G.add(ped);
      const rim = new THREE.Mesh(new THREE.CylinderGeometry(0.46, 0.42, 0.14, 20), brassMat);
      rim.position.set(0.0, D0 + 0.60, -4.4); G.add(rim);
      const airlockCyl = new THREE.Mesh(new THREE.CylinderGeometry(0.28, 0.28, 2.6, 18), pipeMat);
      airlockCyl.position.set(0.65, D0 + 1.3, -4.1); airlockCyl.castShadow = true; G.add(airlockCyl);
      // Horizontal manifold pipes along the rear wall
      for (const py of [1.2, 1.85, 2.5, 3.1]) {
        const hp = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 6.2, 14), pipeMat);
        hp.rotation.z = Math.PI / 2; hp.position.set(0, D0 + py, -3.9); G.add(hp);
      }
      // Row of 5 brass & red valve wheels
      for (let i = 0; i < 5; i++) {
        const vx = -1.3 + i * 0.65, vy = D0 + 1.75 + (i % 2) * 0.42;
        const stem = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.05, 0.32, 10), brassMat);
        stem.rotation.x = Math.PI / 2; stem.position.set(vx, vy, -3.95); G.add(stem);
        const wh = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.045, 10, 20), i === 3 ? redMat : brassMat);
        wh.position.set(vx, vy, -4.12); wh.castShadow = true; G.add(wh);
        this.valveWheels.push(wh);
      }
      // Pressure gauge dials
      for (const gx of [-1.1, 0.95]) {
        const dial = new THREE.Mesh(new THREE.CylinderGeometry(0.26, 0.26, 0.08, 18), flat("#f5f0e1"));
        dial.rotation.x = Math.PI / 2; dial.position.set(gx, D0 + 2.75, -3.82); G.add(dial);
      }
      // 4 HDR glowing bulkhead cage lamps
      addLamp(G, -2.2, D0 + 3.6, -4.2, warmGlow);
      addLamp(G, 2.2, D0 + 3.6, -4.2, warmGlow);
      addLamp(G, 0.0, D0 + 3.8, -5.5, redGlow);
      addLamp(G, 0.65, D0 + 2.8, -4.0, warmGlow);

      // Dynamic seawater geyser column erupting out of the bowl (visible in Shots 14 & 15)
      this.geyserJet = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.22, 2.8, 18), flat("#78c8ff"));
      this.geyserJet.position.set(0.0, D0 + 1.8, -4.4);
      this.geyserJet.visible = false;
      G.add(this.geyserJet);
      R.add(G);
    }

    // =========================================================================
    // SET 2: sub_corridor (control room & corridor outside the WC hatch door)
    // =========================================================================
    {
      const G = this.setCorridor;
      const floor = new THREE.Mesh(new THREE.BoxGeometry(14, 0.2, 16), floorMat);
      floor.position.set(0, D0 - 0.1, -5.5); floor.receiveShadow = true; G.add(floor);
      const backWall = new THREE.Mesh(new THREE.BoxGeometry(12, 5.2, 0.4), steelMat);
      backWall.position.set(0, D0 + 2.6, -3.5); backWall.receiveShadow = true; G.add(backWall);
      // Oval submarine watertight bulkhead hatch doorway
      const doorFrame = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.14, 12, 28), brassMat);
      doorFrame.scale.set(0.75, 1.15, 1); doorFrame.position.set(0.0, D0 + 1.55, -3.65); G.add(doorFrame);
      const doorPlate = new THREE.Mesh(new THREE.CylinderGeometry(0.95, 0.95, 0.12, 24), bulkheadMat);
      doorPlate.rotation.x = Math.PI / 2; doorPlate.scale.set(0.75, 1, 1.15); doorPlate.position.set(0.0, D0 + 1.55, -3.68); G.add(doorPlate);
      const hatchWheel = new THREE.Mesh(new THREE.TorusGeometry(0.28, 0.05, 10, 20), brassMat);
      hatchWheel.position.set(0.0, D0 + 1.55, -3.78); G.add(hatchWheel);
      // Periscope column & overhead pipes
      const peri = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 5.2, 18), pipeMat);
      peri.position.set(-2.4, D0 + 2.6, -5.8); peri.castShadow = true; G.add(peri);
      for (const py of [3.6, 4.1]) {
        const p = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 11, 14), pipeMat);
        p.rotation.z = Math.PI / 2; p.position.set(0, D0 + py, -4.2); G.add(p);
      }
      addLamp(G, -2.5, D0 + 3.8, -4.5, warmGlow);
      addLamp(G, 2.5, D0 + 3.8, -4.5, warmGlow);
      addLamp(G, 0.0, D0 + 3.9, -6.0, redGlow);
      R.add(G);
    }

    // =========================================================================
    // SET 3: ocean_abyss (200 ft underwater U-1206 exterior & cutaway hull)
    // =========================================================================
    {
      const G = this.setAbyss;
      const seabed = new THREE.Mesh(new THREE.BoxGeometry(120, 0.4, 120), flat("#2b5a8a"));
      seabed.position.set(0, D0 - 1.5, 12); seabed.receiveShadow = true; G.add(seabed);
      // Submarine outer hull & conning tower at z = 12
      const hull = new THREE.Mesh(new THREE.CylinderGeometry(2.6, 2.6, 28, 28, 1, false, Math.PI + 0.6, Math.PI * 2 - 1.5), steelMat); // camera-side (-z) cutaway opening so actors inside are visible
      hull.rotation.z = Math.PI / 2; hull.position.set(0, D0 + 1.2, 12.0); hull.castShadow = true; G.add(hull);
      const tower = new THREE.Mesh(new THREE.BoxGeometry(4.2, 2.8, 1.8), steelMat);
      tower.position.set(0, D0 + 3.8, 12.0); tower.castShadow = true; G.add(tower);
      const scope = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.1, 2.6, 10), pipeMat);
      scope.position.set(-0.6, D0 + 5.8, 12.0); G.add(scope);
      // Cutaway interior floor platform at z = 11.2 so characters inside the cutaway stand cleanly at D0
      const cutDeck = new THREE.Mesh(new THREE.BoxGeometry(9.0, 0.25, 3.2), floorMat);
      cutDeck.position.set(0, D0 - 0.12, 11.2); cutDeck.receiveShadow = true; G.add(cutDeck);
      const cutTank = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 2.4, 18), brassMat);
      cutTank.position.set(1.8, D0 + 1.2, 11.4); G.add(cutTank);
      // Interior back bulkhead + lamps for the cutaway (hull far wall is back-face culled)
      const cutBack = new THREE.Mesh(new THREE.BoxGeometry(9.0, 2.8, 0.2), bulkheadMat);
      cutBack.position.set(0, D0 + 1.3, 12.9); G.add(cutBack);
      for (const px of [-2.4, 0, 2.4]) addLamp(G, px, D0 + 2.7, 11.2, warmGlow);
      for (const px of [-6, -3, 3, 6]) addLamp(G, px, D0 + 3.95, 12.0, warmGlow);
      // Glowing HDR portholes & underwater lamps
      for (const px of [-6, -3, 0, 3, 6]) {
        addLamp(G, px, D0 + 2.2, 9.4, warmGlow);
      }
      R.add(G);
    }

    // =========================================================================
    // SET 4: battery_room (giant lead-acid battery bank under steel floor grating)
    // =========================================================================
    {
      const G = this.setBattery;
      const floor = new THREE.Mesh(new THREE.BoxGeometry(12, 0.2, 12), floorMat);
      floor.position.set(0, D0 - 0.1, -5.0); floor.receiveShadow = true; G.add(floor);
      const backWall = new THREE.Mesh(new THREE.BoxGeometry(11, 5.0, 0.4), steelMat);
      backWall.position.set(0, D0 + 2.5, -3.5); G.add(backWall);
      // Row of giant black lead-acid battery cells with copper busbars & glowing green acid tops
      const cellMat = flat(PALETTE.batteryLead);
      for (let i = 0; i < 6; i++) {
        const bx = -2.5 + i * 1.0;
        const cell = new THREE.Mesh(new THREE.BoxGeometry(0.78, 1.15, 1.4), cellMat);
        cell.position.set(bx, D0 + 0.58, -4.6); cell.castShadow = true; G.add(cell);
        const cap = new THREE.Mesh(new THREE.BoxGeometry(0.7, 0.08, 1.2), greenGlow);
        cap.position.set(bx, D0 + 1.18, -4.6); cap.layers.set(NOINK); G.add(cap);
        for (const tx of [-0.2, 0.2]) {
          const term = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.22, 10), brassMat);
          term.position.set(bx + tx, D0 + 1.28, -4.4); G.add(term);
        }
      }
      // Overhead steel grating beams (the toilet room floor directly above)
      for (let x = -3.5; x <= 3.5; x += 0.9) {
        const beam = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.22, 5.0), pipeMat);
        beam.position.set(x, D0 + 3.3, -5.0); G.add(beam);
      }
      // Rising green chlorine gas volume mesh
      this.chlorineFogMesh = new THREE.Mesh(new THREE.BoxGeometry(7.5, 1.6, 3.8), flat(PALETTE.chlorineGreen));
      this.chlorineFogMesh.position.set(0, D0 + 0.9, -4.8);
      G.add(this.chlorineFogMesh);
      addLamp(G, -2.4, D0 + 3.1, -4.0, redGlow);
      addLamp(G, 2.4, D0 + 3.1, -4.0, greenGlow);
      R.add(G);
    }

    // =========================================================================
    // SET 5: north_sea_sky (North Sea surface, sinking U-1206, rubber rafts, RAF bomber)
    // =========================================================================
    {
      const G = this.setSurface;
      const sea = new THREE.Mesh(new THREE.PlaneGeometry(1800, 1800), flat(PALETTE.seaDeep));
      sea.rotation.x = -Math.PI / 2; sea.position.set(0, D0, 0); sea.receiveShadow = true; G.add(sea);

      // Sinking U-1206 hull tilted stern-down in the background at z = 12
      const sHull = new THREE.Mesh(new THREE.CylinderGeometry(2.2, 2.2, 24, 24), steelMat);
      sHull.rotation.z = Math.PI / 2; this.sinkingSubGroup.add(sHull);
      const sTower = new THREE.Mesh(new THREE.BoxGeometry(3.6, 2.6, 1.6), steelMat);
      sTower.position.set(0, 2.6, 0); this.sinkingSubGroup.add(sTower);
      this.sinkingSubGroup.position.set(0, D0 + 0.8, 12.0);
      this.sinkingSubGroup.rotation.z = -0.28;
      G.add(this.sinkingSubGroup);

      // Yellow rubber dinghy rafts in the foreground at z = -4.2
      const raftMat = flat(PALETTE.raftYellow);
      for (const [rx, rz] of [[-0.8, -4.2], [1.4, -4.4]] as const) {
        const ring = new THREE.Mesh(new THREE.TorusGeometry(1.15, 0.28, 12, 24), raftMat);
        ring.rotation.x = Math.PI / 2; ring.position.set(rx, D0 + 0.18, rz); ring.castShadow = true;
        this.raftGroup.add(ring);
        const bottom = new THREE.Mesh(new THREE.CylinderGeometry(1.05, 1.05, 0.12, 20), flat("#c48e1a"));
        bottom.position.set(rx, D0 + 0.08, rz);
        this.raftGroup.add(bottom);
      }
      G.add(this.raftGroup);

      // British RAF bomber banking overhead
      const fuse = new THREE.Mesh(new THREE.BoxGeometry(1.4, 1.2, 9.5), flat("#3c4d3e"));
      const wing = new THREE.Mesh(new THREE.BoxGeometry(13.5, 0.22, 2.2), flat("#495c4b"));
      const tail = new THREE.Mesh(new THREE.BoxGeometry(3.6, 1.4, 0.3), flat("#3c4d3e"));
      tail.position.set(0, 0.7, -4.4);
      this.bomberGroup.add(fuse, wing, tail);
      this.bomberGroup.position.set(-3.0, D0 + 9.5, 8.0);
      this.bomberGroup.rotation.set(0.15, 0.45, -0.22);
      G.add(this.bomberGroup);
      R.add(G);
    }

    // ---- golden-hour shaken soda-bottle table set at KITCHEN (Shot 19) ----
    const [kx, , kz] = KITCHEN;
    const stone = flat("#8d867a"), tableMat = flat("#9a6a3f");
    const kp = new THREE.Mesh(new THREE.BoxGeometry(14, 0.1, 14), stone); kp.position.set(kx, D0 + 0.01, kz); kp.receiveShadow = true; R.add(kp);
    const top = new THREE.Mesh(new THREE.BoxGeometry(3.2, 0.1, 1.0), tableMat); top.position.set(kx, D0 + 0.87, kz); top.castShadow = true; top.receiveShadow = true; R.add(top);
    for (const [lx, lz] of [[-1.5, -0.42], [1.5, -0.42], [-1.5, 0.42], [1.5, 0.42]]) {
      const lg = new THREE.Mesh(new THREE.BoxGeometry(0.1, 0.87, 0.1), tableMat);
      lg.position.set(kx + lx, D0 + 0.43, kz + lz); lg.castShadow = true; R.add(lg);
    }
    const hb = new Batch();
    house(hb, kx - 9, kz + 4, Math.PI / 2 + 0.2, 8, 9, 8.4, 2);
    house(hb, kx + 9.5, kz + 3, -Math.PI / 2 - 0.1, 8, 9, 7, 7);
    house(hb, kx + 1, kz + 12, Math.PI, 12, 9, 9.8, 5);
    hb.build(R);

    // ---- foreground framing props ----
    const cart = (x: number, y: number, z: number, s: number, yaw: number) => {
      const g = new THREE.Group(), w = flat("#9a6a3f"), d = flat("#5a3b24");
      const bed = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.35, 1.0), w); bed.position.y = 0.7; g.add(bed);
      for (const sx of [-1, 1]) { const side = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.45, 1.0), w); side.position.set(sx * 0.9, 1.05, 0); g.add(side); }
      for (const sz of [-1, 1]) { const wh = new THREE.Mesh(new THREE.CylinderGeometry(0.45, 0.45, 0.1, 18), d); wh.rotation.z = Math.PI / 2; wh.position.set(0, 0.45, sz * 0.58); g.add(wh); }
      g.position.set(x, y, z); g.scale.setScalar(s); g.rotation.y = yaw; return g;
    };
    const bush = (x: number, y: number, z: number, s: number) => {
      const g = new THREE.Group(), l = flat("#5aa044");
      for (const [dx, dy, dz, r] of [[0, 0.6, 0, 0.7], [0.5, 0.45, 0.2, 0.5], [-0.45, 0.4, -0.1, 0.5]] as const) {
        const m = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), l); m.position.set(dx, dy, dz); g.add(m);
      }
      g.position.set(x, y, z); g.scale.setScalar(s); return g;
    };
    for (const fg of FOREGROUND) {
      const o = fg.kit === "cart" ? cart(fg.pos[0], fg.pos[1], fg.pos[2], fg.s ?? 1, fg.yaw ?? 0) : bush(fg.pos[0], fg.pos[1], fg.pos[2], fg.s ?? 1);
      o.visible = false; R.add(o); this.fgs.push({ o, a: fg.a, b: fg.b });
    }
  }

  private shotSun(id: number, s: ShotDef, L: LightPreset) {
    let v = this.sunCache.get(id);
    if (v) return v;
    let fx = 0, fz = 0;
    for (let f = s.a; f < s.b; f += 3) {
      const c = camAt(id, f), x = c.look[0] - c.pos[0], z = c.look[2] - c.pos[2], n = Math.hypot(x, z) || 1;
      fx += x / n; fz += z / n;
    }
    const n = Math.hypot(fx, fz) || 1; fx /= n; fz /= n;
    const az = THREE.MathUtils.degToRad(L.az), el = THREE.MathUtils.degToRad(L.el);
    const hx = fx * Math.cos(az) - fz * Math.sin(az), hz = fz * Math.cos(az) + fx * Math.sin(az);
    v = new THREE.Vector3(hx * Math.cos(el), Math.sin(el), hz * Math.cos(el)).normalize();
    this.sunCache.set(id, v);
    return v;
  }
  private actor(i: number) { while (this.actors.length <= i) this.actors.push(new Actor(this.root)); return this.actors[i]; }
  private fx(i: number) { while (this.fxs.length <= i) this.fxs.push(new Fx(this.root)); return this.fxs[i]; }

  /** Updates active location set, animations, sky/light/camera and lit character billboards for frame `f` */
  update(id: number, f: number, cam: THREE.PerspectiveCamera, scene: THREE.Scene): THREE.Vector3 {
    const t = f / FPS, s = SHOTS[id - 1], lname = forcedLight() ?? s.light, L = LIGHTS[lname], K = LOOK[lname];
    const fl: FloodState = floodState(id, t);

    // ---- camera ----
    const c = camAt(id, f);
    cam.position.set(...c.pos); cam.up.set(0, 1, 0); cam.lookAt(...c.look); cam.rotateZ(c.roll);
    cam.fov = c.fov; cam.near = 0.2; cam.far = 1500; cam.updateProjectionMatrix(); cam.updateMatrixWorld();
    const focus = V(...c.look), dist = cam.position.distanceTo(focus);
    cam.layers.enable(NOINK);

    // ---- toggle location sets ----
    this.setToilet.visible = s.location === "toilet_head";
    this.setCorridor.visible = s.location === "sub_corridor" && id !== 19;
    this.setAbyss.visible = s.location === "ocean_abyss";
    this.setBattery.visible = s.location === "battery_room";
    this.setSurface.visible = s.location === "north_sea_sky";

    // ---- dynamic set animations ----
    this.valveWheels.forEach((w, idx) => { w.rotation.z = t * (idx % 2 ? -2.2 : 2.2); });
    this.geyserJet.visible = id === 14 || id === 15;
    if (this.geyserJet.visible) {
      this.geyserJet.scale.set(1 + 0.15 * Math.sin(t * 22), 0.85 + 0.25 * Math.sin(t * 16), 1 + 0.15 * Math.cos(t * 22));
    }
    if (this.setBattery.visible) {
      this.chlorineFogMesh.visible = id === 21;
      this.chlorineFogMesh.scale.y = 0.5 + 0.6 * Math.max(0, (t - 54.35) / 3.2);
    }
    if (this.setSurface.visible) {
      const uSink = Math.max(0, (t - 60.33) / 4.7);
      this.sinkingSubGroup.position.y = D0 + 0.8 - uSink * 1.6;
      this.sinkingSubGroup.rotation.z = -0.22 - uSink * 0.25;
      this.raftGroup.position.y = 0.08 * Math.sin(t * 3.5);
      this.bomberGroup.position.x = -5.0 + uSink * 8.5;
    }

    // ---- light rig ----
    const sunDir = this.shotSun(id, s, L);
    this.hemi.color.set(L.sky); this.hemi.groundColor.set(L.ground); this.hemi.intensity = L.hemiI;
    this.sun.color.set(L.sunCol); this.sun.intensity = L.sunI;
    let Rr = THREE.MathUtils.clamp(dist * 1.15 + 7, 12, 95);
    if (id === 5 || id === 16 || id === 23) Rr = Math.max(Rr, 55);
    if (lname === "golden" || lname === "night") Rr = Math.max(Rr, 30);
    this.sun.position.copy(focus).addScaledVector(sunDir, 220); this.sun.target.position.copy(focus);
    const sc = this.sun.shadow.camera;
    sc.left = -Rr; sc.right = Rr; sc.top = Rr; sc.bottom = -Rr; sc.near = 20; sc.far = 480; sc.updateProjectionMatrix();
    this.sun.shadow.bias = L.bias; this.sun.shadow.normalBias = L.normalBias * (Rr / 12);
    this.fill.intensity = 0;
    TONE.uLitCol.value.set(...L.lit); TONE.uShadeCol.value.set(...L.shade); TONE.uShadeLift.value.set(...L.lift);
    TONE.uLambert.value = L.lambert; TONE.uSideK.value = L.sideK; TONE.uTerm.value = L.term; TONE.uBounce.value.set(...K.bounce); TONE.uSat.value = K.sat;
    CHAR.uCharTint.value.set(...L.charTint); CHAR.uCharShade.value = L.charShade; CHAR.uGrad.value = L.charGrad;
    CHAR.uBodyGrad.value = L.bodyGrad; CHAR.uSideTint.value.set(...L.sideTint);

    // ---- sky, fog, sun disc, clouds ----
    const su = this.skyMat.uniforms;
    K.sky.c.forEach((h, i) => untone(h, su["c" + i].value));
    const e = K.sky.e.map((deg) => THREE.MathUtils.degToRad(deg));
    su.e.value.set(e[1], e[2], e[3], e[4]);
    this.sky.position.copy(cam.position);
    untone(L.fog, this.fog.color); this.fog.near = L.fogNear; this.fog.far = L.fogFar;
    scene.fog = this.fog; scene.background = null;
    const showSun = lname === "golden" || lname === "night";
    this.sunDisc.visible = this.sunHalo.visible = showSun;
    if (showSun) {
      this.sunDisc.position.copy(cam.position).addScaledVector(sunDir, 900);
      this.sunDisc.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(1.7)));
      this.sunHalo.position.copy(this.sunDisc.position); this.sunHalo.scale.setScalar(2 * 900 * Math.tan(THREE.MathUtils.degToRad(24)));
      (this.sunHalo.material as THREE.SpriteMaterial).color.set(L.sunDisc).multiplyScalar(1.3);
    }
    for (let i = 0; i < this.clouds.length; i++) {
      const m = this.clouds[i], mat = m.material as THREE.MeshBasicMaterial;
      m.lookAt(cam.position.x, m.position.y, cam.position.z);
      mat.map = this.cloudMaps[lname][i % 4];
    }
    for (const g of this.fgs) g.o.visible = f >= g.a && f < g.b && g.a < s.b && g.b > s.a;

    // ---- cast + effects as lit billboards ----
    const right = V(0, 0, 0).setFromMatrixColumn(cam.matrixWorld, 0);
    const st = stage(id, t, fl, { pos: cam.position, right });
    this.frustum.setFromProjectionMatrix(this.m4.multiplyMatrices(cam.projectionMatrix, cam.matrixWorldInverse));
    const tint = lname === "golden" ? "#ffcf9e" : lname === "night" ? "#bcd0ff" : lname === "dusk" ? "#ffd7a8" : "#ffffff";
    let ai = 0; const used: Actor[] = [];
    for (const p of st.places) {
      const sc2 = p.scale ?? 1;
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y + 1.1 * sc2, p.z), 3.5))) continue;
      const a = this.actor(ai++);
      const [w, h, k] = p.size ?? [300, 500, 0.5];
      a.r = this.pool.req(p.key, w, h, k, p.draw);
      a.mesh.visible = true; a.mesh.position.set(p.x, p.y, p.z);
      a.mesh.rotation.set(0, p.yaw ?? Math.atan2(cam.position.x - p.x, cam.position.z - p.z), p.roll ?? 0);
      a.mesh.scale.set(p.mirror ? -sc2 : sc2, sc2, sc2);
      if (a.mat.emissiveMap) a.mat.emissive.set(tint);
      a.mesh.castShadow = L.actorShadow;
      used.push(a);
    }
    for (let i = ai; i < this.actors.length; i++) this.actors[i].mesh.visible = false;
    let fi = 0; const fused: Fx[] = [];
    for (const p of st.fx) {
      if (!this.frustum.intersectsSphere(this.sph.set(this.v.set(p.x, p.y, p.z), Math.max(p.w, p.h)))) continue;
      const ex = this.fx(fi++);
      ex.r = this.pool.req(p.key, p.cw, p.ch, 1, p.draw);
      ex.use(!!p.soft); ex.mesh.visible = true; ex.mesh.position.set(p.x, p.y, p.z);
      if (p.flat) ex.mesh.rotation.set(-Math.PI / 2, 0, p.rot ?? 0);
      else { ex.mesh.quaternion.copy(cam.quaternion); ex.mesh.rotateZ(p.rot ?? 0); }
      ex.mesh.scale.set(p.w, p.h, 1);
      fused.push(ex);
    }
    for (let i = fi; i < this.fxs.length; i++) this.fxs[i].mesh.visible = false;
    this.pool.flush();
    for (const a of used) a.bind();
    for (const x of fused) x.bind();
    return focus;
  }
}