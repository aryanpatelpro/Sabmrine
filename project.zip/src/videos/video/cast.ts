// Cast for "The Toilet That Sank a Submarine" (U-1206, April 1945).
// Engine (canvas pool, lit billboards, contact blobs, blinks) = the skill's cast.ts; roster, outfits, props and
// per-shot staging = this story. Character style is LOCKED (toon.ts). Every visible character uses the idle-life
// recipe + per-shot action verb + mid-shot expression change on spoken words + >=1 effect card per shot.

import * as THREE from "three";
import { getInputProps } from "remotion";
import {
  Pen, bodyFront, bodySide, townsfolk, fxBurst, fxStars, fxCreak, fxPuff, fxSplash, fxRing, fxShadow, fxContact,
  Outfit, Expr, FrontOpts, SideOpts,
} from "./toon";
import {
  FPS, D0, KITCHEN, SHOTS, V3, FloodState, clamp01,
} from "./story";
import { forcedLight } from "./lights";
import { NOINK } from "./ink";
import { cardShade, blobMaterial, CARD_K } from "./cardshade";

// ---------------- canvas pool ----------------
type Entry = { cv: HTMLCanvasElement; tex: THREE.CanvasTexture; w: number; h: number };
export type Req = { key: string; w: number; h: number; k: number; draw: (p: Pen) => void; tex?: THREE.CanvasTexture };
const makeEntry = (w: number, h: number): Entry => {
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const tex = new THREE.CanvasTexture(cv);
  tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 8;
  return { cv, tex, w, h };
};
export class Pool {
  private live = new Map<string, Entry>();
  private free: Entry[] = [];
  private reqs: Req[] = [];
  req(key: string, w: number, h: number, k: number, draw: (p: Pen) => void) {
    const r: Req = { key: `${w}x${h}|${key}`, w, h, k, draw };
    this.reqs.push(r);
    return r;
  }
  flush() {
    const want = new Map<string, Req[]>();
    for (const r of this.reqs) { const l = want.get(r.key); if (l) l.push(r); else want.set(r.key, [r]); }
    for (const [key, e] of this.live) if (!want.has(key)) { this.live.delete(key); this.free.push(e); }
    for (const [key, rs] of want) {
      let e = this.live.get(key);
      if (!e) {
        const r = rs[0], i = this.free.findIndex((x) => x.w === r.w && x.h === r.h);
        e = i >= 0 ? this.free.splice(i, 1)[0] : makeEntry(r.w, r.h);
        const g = e.cv.getContext("2d")!;
        g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, e.w, e.h); g.setTransform(r.k, 0, 0, r.k, 0, 0);
        r.draw(new Pen(g));
        e.tex.needsUpdate = true;
        this.live.set(key, e);
      }
      for (const r of rs) r.tex = e.tex;
    }
    this.reqs = [];
  }
}

// ---------------- sprite meshes ----------------
const blank = (() => { const c = document.createElement("canvas"); c.width = c.height = 2; return new THREE.CanvasTexture(c); })();
export const SU = 0.00216; // metres per design unit: 1000 units = 2.16 m
export const SU_SWING = 2.3 / 1830;
const BODY = (() => { const g = new THREE.PlaneGeometry(600 * SU, 1000 * SU); g.translate(0, (975 - 500) * SU, 0); return g; })();
const CARD = new THREE.PlaneGeometry(1, 1);
const ROOTS = new Set<THREE.Object3D>();

export class Actor {
  mesh: THREE.Mesh; mat: THREE.MeshLambertMaterial; dmat: THREE.MeshDepthMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D, geo: THREE.BufferGeometry = BODY) {
    this.mat = cardShade(new THREE.MeshLambertMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide }));
    this.mat.alphaToCoverage = false;
    this.dmat = new THREE.MeshDepthMaterial({ depthPacking: THREE.RGBADepthPacking, map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mesh = new THREE.Mesh(geo, this.mat);
    this.mesh.customDepthMaterial = this.dmat;
    this.mesh.onBeforeRender = (r) => { const rt = r.getRenderTarget(); CARD_K.uPx.value = (rt ? rt.height : r.domElement.height) / 1920; };
    this.mesh.castShadow = false; this.mesh.receiveShadow = true; this.mesh.visible = false;
    this.mesh.rotation.order = "YXZ"; this.mesh.renderOrder = 1; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
    ROOTS.add(parent);
  }
  bind() { const t = this.r?.tex; if (t) { this.mat.map = t; this.dmat.map = t; } }
}

export class Fx {
  mesh: THREE.Mesh; mat: THREE.MeshBasicMaterial; soft: THREE.MeshBasicMaterial; blob: THREE.MeshBasicMaterial; r: Req | null = null;
  constructor(parent: THREE.Object3D) {
    this.mat = new THREE.MeshBasicMaterial({ map: blank, alphaTest: 0.5, side: THREE.DoubleSide });
    this.mat.alphaToCoverage = false;
    this.soft = new THREE.MeshBasicMaterial({ map: blank, transparent: true, depthWrite: false, side: THREE.DoubleSide });
    this.blob = blobMaterial(blank);
    this.mesh = new THREE.Mesh(CARD, this.mat);
    this.mesh.visible = false; this.mesh.layers.set(NOINK);
    parent.add(this.mesh);
  }
  use(soft: boolean) { this.mesh.material = soft ? this.soft : this.mat; }
  bind() {
    const t = this.r?.tex;
    if (!t) return;
    if (this.r!.key.includes("|blob|")) {
      if (t.generateMipmaps) { t.generateMipmaps = false; t.minFilter = THREE.LinearFilter; t.needsUpdate = true; }
      this.blob.map = t; this.mesh.material = this.blob; this.mesh.renderOrder = 0.5;
    } else {
      this.mat.map = t; this.soft.map = t; this.mesh.renderOrder = 0;
    }
  }
}

// ---------------- placements ----------------
export type Place = {
  key: string; draw: (p: Pen) => void; x: number; y: number; z: number;
  scale?: number; mirror?: boolean; yaw?: number; geo?: "body" | "swing"; roll?: number; size?: [number, number, number];
};
export type FxPlace = { key: string; cw: number; ch: number; draw: (p: Pen) => void; x: number; y: number; z: number; w: number; h: number; flat?: boolean; rot?: number; soft?: boolean };
export type CamInfo = { pos: THREE.Vector3; right: THREE.Vector3; sun?: THREE.Vector3 };

const hh = (i: number, s = 0) => { const v = Math.sin(i * 127.1 + s * 311.7) * 43758.5453; return v - Math.floor(v); };
const q = (v: number, n = 60) => Math.round(v * n) / n;
const seedOf = (i: number) => ((i * 5 + 3) % 7) + 1;
const CARD_Q = (getInputProps() as { post?: { cardQ?: number } }).post?.cardQ ?? 1;
const tier = (d: number): [number, number, number] => {
  const [w, h, k] = d < 3.2 ? [1800, 3000, 3.0] : d < 6.5 ? [1080, 1800, 1.8] : d < 16 ? [480, 800, 0.8] : [240, 400, 0.4];
  return [Math.round(w * CARD_Q), Math.round(h * CARD_Q), k * CARD_Q];
};

// ---------------- light ----------------
const SUN = new THREE.Vector3(0.5, 0.75, -0.4).normalize();
const tmp = new THREE.Vector3();
let LNAME: "day" | "golden" | "night" | "dusk" = "dusk";
const sunOf = (root: THREE.Object3D) => {
  let s: THREE.DirectionalLight | null = null;
  root.traverse((o) => { if (!s && o instanceof THREE.DirectionalLight && o.castShadow) s = o; });
  return s as THREE.DirectionalLight | null;
};
const findSun = (cam: CamInfo, out: THREE.Vector3) => {
  if (cam.sun) return out.copy(cam.sun).normalize();
  let best: THREE.DirectionalLight | null = null, err = Infinity;
  for (const r of ROOTS) {
    if (!r.parent) continue;
    const s = sunOf(r);
    if (!s) continue;
    const d = tmp.copy(s.target.position).sub(cam.pos), e = Math.abs(d.dot(cam.right)) / (d.length() || 1);
    if (e < err) { err = e; best = s; }
  }
  return best ? out.copy(best.position).sub(best.target.position).normalize() : out;
};
const light2D = (cam: CamInfo, mirror: boolean) => {
  const sx = SUN.dot(cam.right) * (mirror ? -1 : 1), sy = -SUN.y;
  return Math.round(Math.atan2(sy, sx) / (Math.PI / 4)) * (Math.PI / 4);
};

// ---------------- blinks & idle recipe (references/06-acting-and-effects.md) ----------------
const LEAD = 2 / FPS;
const LID = [0.5, 1, 1, 0.5];
const lidAt = (t: number, i: number, swaps: number[] = []) => {
  const f = Math.round(t * FPS);
  for (const ts of swaps) {
    const k = f - Math.round((ts - LEAD) * FPS) + 1;
    if (k >= 0 && k < 4) return LID[k];
  }
  let s = Math.round(-60 * hh(i, 9));
  for (let n = 0; s <= f && n < 400; n++) {
    const k = f - s;
    if (k >= 0 && k < 4) return LID[k];
    s += Math.round(15 + 54 * hh(i * 31 + n, 13));
  }
  return 0;
};

/** Idle life recipe from references/06-acting-and-effects.md (applied to every character, every frame) */
const idle = (t: number, i: number, swaps: number[] = []) => ({
  headTilt: q(3 * Math.sin(t * 1.6 + i), 10),
  tilt: q(1.5 * Math.sin(t * 1.1 + i * 2), 10),
  look: Math.sin(t * 0.7 + i) > 0.55 ? 1 : 0,
  blink: lidAt(t, i, swaps),
});

const fkey = (o: object) => JSON.stringify(o, (_k, v) => (typeof v === "number" ? q(v, 20) : v));

type Who = { i: number; o: Outfit; okey: string };
const person = (cam: CamInfo, who: Who, x: number, y: number, z: number, view: { side: boolean; mirror: boolean }, fo: FrontOpts, so: SideOpts, scale = 1): Place & { tierKey: string } => {
  const d = cam.pos.distanceTo(tmp.set(x, y + 1.2, z)) / scale;
  const [w, h, k] = tier(d);
  const mirror = view.side && view.mirror, light = light2D(cam, mirror), seed = seedOf(who.i);
  const f2: FrontOpts = { ...fo, light, seed }, s2: SideOpts = { ...so, light, seed };
  const key = view.side ? `S|${who.okey}|${fkey(s2)}` : `F|${who.okey}|${fkey(f2)}`;
  return {
    key, x, y, z, scale, mirror, tierKey: `${w}`,
    draw: (p) => (view.side ? bodySide(p, who.o, s2) : bodyFront(p, who.o, f2)),
    size: [w, h, k],
  };
};

const CONTACT: Record<"day" | "golden" | "night" | "dusk", [number, number, number]> = {
  day: [0.2, 0.21, 0.33], golden: [0.24, 0.2, 0.33], night: [0.1, 0.14, 0.3], dusk: [0.26, 0.2, 0.3],
};
const TAIL: [number, number, number] = [0.42, 0.44, 0.62];
const toSrgb = (v: number) => { const c = clamp01(v); return c <= 0.0031308 ? 12.92 * c : 1.055 * c ** (1 / 2.4) - 0.055; };
const hexOf = (c: [number, number, number], k: number) => "#" + c.map((v) => Math.round(255 * toSrgb(1 - (1 - v) * k)).toString(16).padStart(2, "0")).join("");
const blob = (out: Stage, x: number, y: number, z: number, sc = 1, k = 1) => {
  const hl = Math.hypot(SUN.x, SUN.z) || 1, ox = -SUN.x / hl, oz = -SUN.z / hl, rot = Math.atan2(-ox, -oz);
  if (LNAME === "day") {
    const el = Math.asin(Math.min(0.99, Math.max(0.1, SUN.y)));
    const len = Math.min(2.4, Math.max(0.5, 1.6 / Math.tan(el))) * sc, h = len + 0.55 * sc, c = 0.3 * h;
    const tc = hexOf(TAIL, k);
    out.fx.push({ key: `blob|shadow|${tc}`, cw: 128, ch: 256, draw: (p) => fxShadow(p, tc), x: x + ox * c, y: y + 0.018, z: z + oz * c, w: 0.72 * sc, h, flat: true, rot });
  }
  const cc = hexOf(CONTACT[LNAME], k);
  out.fx.push({ key: `blob|contact|${cc}`, cw: 128, ch: 128, draw: (p) => fxContact(p, cc), x: x + ox * 0.03 * sc, y: y + 0.022, z: z + oz * 0.03 * sc, w: 0.52 * sc, h: 0.4 * sc, flat: true, rot });
};

// ---------------- Custom U-1206 Submarine Outfits ----------------
export const CAPTAIN: Outfit = {
  jacket: "#1f2d42", pants: "#182232", boots: "#241726", hat: "shako_tall",
  buttons: "#f0c850", sash: "#d49b38", moustache: "#3b2818", build: "stout",
};
export const SPECIALIST: Outfit = {
  jacket: "#355e7d", pants: "#283645", boots: "#241726", hat: "cap",
  cap: "#d43f3a", belt: "#e8cfa4", buttons: "#e8c45a",
};
export const SAILOR: Outfit = {
  jacket: "#2e4d6b", pants: "#263240", boots: "#241726", hat: "cap",
  cap: "#f0ece1", belt: "#3d2b1f",
};
export const ENGINEER: Outfit = {
  jacket: "#42525c", pants: "#2b3138", boots: "#241726", hat: "cap",
  cap: "#3b424c", belt: "#5a3b24", moustache: "#2a201a",
};

// ---------------- Custom 2D Pen Prop & Effect Cards (600x1000 or 300x300) ----------------
export const fxExclamation = (p: Pen, col = "#ff4438", qmark = false) => {
  if (qmark) {
    p.arc(150, 110, 42, 42, 180, 380, 22, col);
    p.line([[188, 120], [150, 175], [150, 200]], col, 22);
    p.ell(150, 248, 16, 16, col, 10);
  } else {
    p.poly([[132, 55], [168, 55], [160, 195], [140, 195]], col, 12);
    p.ell(150, 242, 18, 18, col, 10);
  }
};

export const fxSweatDrop = (p: Pen, u: number) => {
  const dy = (u % 1) * 45;
  p.poly([[150, 70 + dy], [182, 145 + dy], [150, 185 + dy], [118, 145 + dy]], "#7ad0ff", 10);
  p.ell(150, 152 + dy, 30, 26, "#7ad0ff", 8);
};

export const fxManualBook = (p: Pen, openAmt = 1) => {
  const w = 95 * openAmt;
  p.poly([[300 - w, 460], [300, 475], [300, 650], [300 - w, 635]], "#f5efe0", 10);
  p.poly([[300, 475], [300 + w, 460], [300 + w, 635], [300, 650]], "#e8dec6", 10);
  p.line([[300 - w * 0.75, 510], [300 - w * 0.2, 520]], "#c93838", 7);
  p.line([[300 + w * 0.2, 520], [300 + w * 0.75, 510]], "#3b6e8c", 7);
  p.ell(300 + w * 0.48, 575, 22, 22, "#e8b838", 8);
};

export const fxValveDiagram = (p: Pen, step: 1 | 2) => {
  p.poly([[140, 280], [460, 280], [460, 620], [140, 620]], "#1a2b42", 14);
  // Pipe & 2 airlock doors
  p.poly([[265, 310], [335, 310], [335, 590], [265, 590]], "#58697a", 10);
  // Top valve gate
  p.poly([[235, 380], [365, 380], [365, 408], [235, 408]], step === 1 ? "#3ad468" : "#c93838", 10);
  // Bottom sea valve gate
  p.poly([[235, 500], [365, 500], [365, 528], [235, 528]], step === 2 ? "#3ad468" : "#c93838", 10);
  // Arrow
  if (step === 2) {
    p.poly([[285, 430], [315, 430], [315, 545], [338, 545], [300, 585], [262, 545], [285, 545]], "#ffd84a", 8);
  } else {
    p.ell(300, 455, 26, 26, "#7ad0ff", 8);
  }
};

export const fxSodaBottle = (p: Pen, t: number) => {
  const fizz = Math.sin(t * 18) * 14;
  p.poly([[265, 520], [335, 520], [345, 760], [255, 760]], "#2f7a4e", 12);
  p.poly([[282, 450], [318, 450], [325, 520], [275, 520]], "#2f7a4e", 10);
  // Foam geyser erupting out the top
  p.poly([[285, 450], [315, 450], [375, 230 + fizz], [225, 230 - fizz]], "#ffffff", 10);
  p.ell(300, 220 + fizz, 82, 42, "#e8f8ff", 10);
};

export const fxChlorineCloud = (p: Pen, u: number) => {
  const dy = (u % 1) * 55;
  for (const [cx, cy, r] of [[110, 190, 52], [160, 145, 68], [210, 185, 56], [150, 215, 60]] as const) {
    p.ell(cx, cy - dy, r, r * 0.78, "#5ee868", 8);
  }
};

export const fxPressureArrow = (p: Pen, u: number) => {
  const dx = (u % 1) * 40;
  p.poly([[60 + dx, 125], [175 + dx, 125], [175 + dx, 92], [245 + dx, 150], [175 + dx, 208], [175 + dx, 175], [60 + dx, 175]], "#4cc8ff", 10);
};

export type Stage = { places: Place[]; fx: FxPlace[] };

const designCard = (out: Stage, cam: CamInfo, key: string, draw: (p: Pen) => void, x: number, y0: number, z: number, s = 1, dx = 0, dy = 0, towards = 0.12) => {
  const tx = cam.pos.x - x, tz = cam.pos.z - z, tl = Math.hypot(tx, tz) || 1;
  out.fx.push({
    key, cw: 600, ch: 1000, draw,
    x: x + cam.right.x * dx + (tx / tl) * towards,
    y: y0 + 0.475 * 2.16 * s + dy,
    z: z + cam.right.z * dx + (tz / tl) * towards,
    w: 600 * SU * s, h: 1000 * SU * s,
  });
};

/** All cast, props and effects of shot `id` at time `t` */
export const stage = (id: number, t: number, _fl: FloodState, cam: CamInfo): Stage => {
  const out: Stage = { places: [], fx: [] };
  const s = SHOTS[id - 1];
  LNAME = forcedLight() ?? s.light;
  findSun(cam, SUN);
  const front = { side: false, mirror: false };
  const mid = (s.a + s.b) / (2 * FPS); // midpoint time of current shot for expression change

  const put = (i: number, o: Outfit, okey: string, x: number, y: number, z: number, fo: FrontOpts, swaps: number[] = [mid], scale = 1, shadow = true) => {
    const idl = idle(t, i, swaps);
    const merged: FrontOpts = {
      ...idl,
      ...fo,
      headTilt: (fo.headTilt ?? 0) + idl.headTilt,
      tilt: (fo.tilt ?? 0) + idl.tilt,
      blink: fo.blink ?? idl.blink,
    };
    out.places.push(person(cam, { i, o, okey }, x, y, z, front, merged, {}, scale));
    if (shadow) blob(out, x, y, z, 1.05 * scale);
  };

  const uShot = clamp01((t - s.a / FPS) / Math.max(0.1, (s.b - s.a) / FPS));
  const ph = q((t * 1.8) % 1, 20);
  const wv = q(Math.sin(t * 6), 12);

  switch (s.crowd) {
    case "hook_lock": {
      // Shot 1: Captain locks bathroom latch and grabs brass valve wheel (stern -> grin)
      const expr: Expr = t < mid ? "stern" : "grin";
      put(1, CAPTAIN, "cap", 0.0, D0, -5.0, { mode: "march", phase: ph, expr, wave: wv, facing: 1 });
      out.fx.push({ key: `spark1_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#ffd84a", 8, 30, 170), x: 0.55, y: D0 + 1.65, z: -4.7, w: 0.75, h: 0.75 });
      out.fx.push({ key: "qmark1", cw: 300, ch: 300, draw: (p) => fxExclamation(p, "#ffd84a", true), x: -0.45, y: D0 + 2.15, z: -4.8, w: 0.55, h: 0.55 });
      break;
    }
    case "valves_cu": {
      // Shot 2: Insert of gleaming brass valves + Captain reaching across (grin -> neutral)
      const expr: Expr = t < mid ? "grin" : "neutral";
      put(1, CAPTAIN, "cap", -0.35, D0, -5.0, { mode: "stroll", phase: ph, expr, prop: ["hammer", q(uShot, 15)], facing: 1 });
      out.fx.push({ key: `glint2_${q(uShot, 15)}`, cw: 420, ch: 210, draw: (p) => fxStars(p, q(uShot, 15)), x: 0.25, y: D0 + 1.75, z: -4.6, w: 0.85, h: 0.45 });
      break;
    }
    case "corridor_knock": {
      // Shot 3: Sailor laughs and knocks outside door; Captain waves him off
      const exSailor: Expr = t < mid ? "grin" : "laugh";
      const exCap: Expr = t < mid ? "stern" : "smile_closed";
      put(2, SAILOR, "sal", -0.85, D0, -5.2, { mode: "march", phase: ph, expr: exSailor, wave: wv, facing: 1 });
      put(1, CAPTAIN, "cap", 0.65, D0, -5.0, { mode: "stroll", phase: ph, expr: exCap, wave: -wv, facing: -1 });
      out.fx.push({ key: `knock3_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q((uShot * 2) % 1, 15), "#fff3b0", 10, 35, 190), x: -0.15, y: D0 + 1.55, z: -4.9, w: 0.8, h: 0.8 });
      out.fx.push({ key: `puff3_${q(uShot, 12)}`, cw: 300, ch: 300, draw: (p) => fxPuff(p, q(uShot, 12)), x: -0.85, y: D0 + 2.1, z: -5.0, w: 0.7, h: 0.7, soft: true });
      break;
    }
    case "captain_smug": {
      // Shot 4: Hero CU Captain pats toilet bowl ("It is just a toilet.")
      const expr: Expr = t < mid ? "smile_closed" : "grin";
      put(1, CAPTAIN, "cap", 0.0, D0, -5.0, { mode: "stroll", phase: ph, expr, wave: wv, tilt: 5 });
      out.fx.push({ key: `smug4_${q(uShot, 15)}`, cw: 420, ch: 210, draw: (p) => fxStars(p, q(uShot, 15)), x: 0.35, y: D0 + 2.05, z: -4.8, w: 0.75, h: 0.4 });
      break;
    }
    case "abyss_aerial": {
      // Shot 5: Top-down aerial of U-1206 200 ft underwater off Scotland
      const expr: Expr = t < mid ? "neutral" : "stern";
      put(1, CAPTAIN, "cap", 0.0, D0 + 1.2, 12.0, { mode: "march", phase: ph, expr, wave: wv }, [mid], 1.1, false);
      out.fx.push({ key: `ring5_${q(uShot, 15)}`, cw: 600, ch: 600, draw: (p) => fxRing(p, q(uShot, 15)), x: 0.0, y: D0 + 3.2, z: 12.0, w: 6.5, h: 6.5, flat: true });
      break;
    }
    case "septic_cutaway": {
      // Shot 6: Cutaway of submarine septic tanks underwater
      const expr: Expr = t < mid ? "pained" : "neutral";
      put(2, SAILOR, "sal", -1.2, D0, 11.2, { mode: "march", phase: ph, expr, tilt: -6, lift: 75 });
      out.fx.push({ key: `creak6_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxCreak(p, q(uShot, 15)), x: 0.8, y: D0 + 2.1, z: 11.0, w: 0.9, h: 0.9 });
      break;
    }
    case "german_blueprint": {
      // Shot 7: Golden light - Specialist & Engineer with high-pressure deep-sea toilet blueprint
      put(3, SPECIALIST, "spc", -0.7, D0, -4.6, { mode: "stroll", phase: ph, expr: t < mid ? "neutral" : "smile", wave: wv, facing: 1 });
      put(4, ENGINEER, "eng", 0.8, D0, -4.6, { mode: "march", phase: ph, expr: t < mid ? "stern" : "grin", prop: ["hammer", q((uShot * 2) % 1, 15)], facing: -1 });
      designCard(out, cam, "diag7", (p) => fxValveDiagram(p, 1), 0.05, D0, -4.4, 0.75, 0, 0.15, 0.15);
      out.fx.push({ key: `spark7_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#ffd84a", 10, 30, 180), x: 0.8, y: D0 + 1.6, z: -4.3, w: 0.75, h: 0.75 });
      break;
    }
    case "air_shoot": {
      // Shot 8: Insert of waste/air shooting straight out into the deep sea
      put(3, SPECIALIST, "spc", -1.1, D0, 11.5, { mode: "march", phase: ph, expr: t < mid ? "smile" : "stern", wave: wv });
      out.fx.push({ key: `splash8_${q(uShot, 15)}`, cw: 800, ch: 800, draw: (p) => fxSplash(p, q(uShot, 15)), x: 0.6, y: D0 + 1.8, z: 11.2, w: 2.4, h: 2.4 });
      out.fx.push({ key: `puff8_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxPuff(p, q(uShot, 15)), x: 1.4, y: D0 + 2.2, z: 11.0, w: 1.5, h: 1.5, soft: true });
      break;
    }
    case "specialist_rule": {
      // Shot 9: Hero CU Specialist holds up warning finger ("only a trained specialist can flush it")
      put(3, SPECIALIST, "spc", 0.0, D0, -5.0, { mode: "stroll", phase: ph, expr: t < mid ? "stern" : "smile_closed", wave: 0.9, facing: 1 });
      out.fx.push({ key: "excl9", cw: 300, ch: 300, draw: (p) => fxExclamation(p, "#ff4438", false), x: 0.48, y: D0 + 2.05, z: -4.8, w: 0.6, h: 0.6 });
      break;
    }
    case "manual_study": {
      // Shot 10: Specialist studies thick manual while crew roll their eyes
      put(3, SPECIALIST, "spc", -1.1, D0, -5.0, { mode: "stroll", phase: ph, expr: t < mid ? "neutral" : "nervous", facing: 1 });
      put(2, SAILOR, "sal", 0.25, D0, -5.1, { mode: "march", phase: ph, expr: t < mid ? "grin" : "laugh", wave: wv, facing: -1 });
      put(5, townsfolk(1), "crw", 1.25, D0, -4.9, { mode: "stroll", phase: ph, expr: t < mid ? "smile" : "whistle", headTilt: 10, facing: -1 });
      designCard(out, cam, "book10", (p) => fxManualBook(p, 1), -0.75, D0, -4.8, 0.75, 0.15, -0.05, 0.18);
      out.fx.push({ key: `puff10_${q(uShot, 12)}`, cw: 300, ch: 300, draw: (p) => fxPuff(p, q(uShot, 12)), x: 0.5, y: D0 + 2.1, z: -4.9, w: 0.75, h: 0.75, soft: true });
      break;
    }
    case "day_eight": {
      // Shot 11: Day 8 - Captain strides into toilet compartment determined to do it himself
      put(1, CAPTAIN, "cap", -0.2, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "stern" : "grin", lift: 80, facing: 1 });
      put(2, SAILOR, "sal", -1.45, D0, -5.4, { mode: "stroll", phase: ph, expr: t < mid ? "whistle" : "neutral", wave: wv, facing: 1 });
      out.fx.push({ key: `sweat11_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxSweatDrop(p, q(uShot, 15)), x: -1.35, y: D0 + 2.05, z: -5.2, w: 0.5, h: 0.5 });
      break;
    }
    case "wheel_stuck": {
      // Shot 12: Captain strains on stuck wheel, then calls Specialist in
      put(1, CAPTAIN, "cap", -0.35, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "grin" : "nervous", tilt: -9, wave: wv, facing: 1 });
      put(3, SPECIALIST, "spc", 0.65, D0, -5.1, { mode: "march", phase: ph, expr: t < mid ? "neutral" : "shock", lift: 85, facing: -1 });
      out.fx.push({ key: `creak12_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxCreak(p, q(uShot, 15)), x: 0.05, y: D0 + 1.75, z: -4.7, w: 0.8, h: 0.8 });
      out.fx.push({ key: `sweat12_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxSweatDrop(p, q(uShot, 15)), x: -0.5, y: D0 + 2.05, z: -4.8, w: 0.55, h: 0.55 });
      break;
    }
    case "wrong_valve": {
      // Shot 13: In the panic, Specialist yanks outer sea valve open first
      put(3, SPECIALIST, "spc", 0.25, D0, -4.9, { mode: "march", phase: ph, expr: t < mid ? "nervous" : "shock", prop: ["hammer", q(uShot, 15)], facing: -1 });
      put(1, CAPTAIN, "cap", -0.55, D0, -5.1, { mode: "march", phase: ph, expr: t < mid ? "nervous" : "shock", wave: 1.0, facing: 1 });
      out.fx.push({ key: `burst13_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#ff4438", 12, 40, 220), x: 0.2, y: D0 + 1.75, z: -4.6, w: 1.1, h: 1.1 });
      out.fx.push({ key: "excl13", cw: 300, ch: 300, draw: (p) => fxExclamation(p, "#ff4438", false), x: 0.35, y: D0 + 2.2, z: -4.7, w: 0.65, h: 0.65 });
      break;
    }
    case "geyser_blast": {
      // Shot 14: Freezing seawater blasts back through the bowl
      put(1, CAPTAIN, "cap", -0.65, D0, -5.1, { mode: "fall", phase: ph, expr: t < mid ? "shock" : "pained", tilt: -14, facing: 1 });
      put(3, SPECIALIST, "spc", 0.65, D0, -5.1, { mode: "march", phase: ph, expr: t < mid ? "shock" : "dazed", wave: 1.0, facing: -1 });
      out.fx.push({ key: `geyser14_${q(uShot, 15)}`, cw: 800, ch: 800, draw: (p) => fxSplash(p, q((uShot * 1.5) % 1, 15)), x: 0.0, y: D0 + 1.5, z: -4.7, w: 2.2, h: 2.4 });
      out.fx.push({ key: `burst14_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#bfe8ff", 10, 35, 200), x: 0.0, y: D0 + 2.1, z: -4.6, w: 1.3, h: 1.3 });
      break;
    }
    case "captain_scream": {
      // Shot 15: Hero CU Captain screams "Shut it!" Too late.
      put(1, CAPTAIN, "cap", 0.0, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "shock" : "pained", wave: wv, tilt: -8 });
      out.fx.push({ key: `scream15_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#ff4438", 12, 45, 230), x: 0.4, y: D0 + 1.95, z: -4.8, w: 0.95, h: 0.95 });
      out.fx.push({ key: `splash15_${q(uShot, 15)}`, cw: 800, ch: 800, draw: (p) => fxSplash(p, q(uShot, 15)), x: -0.3, y: D0 + 1.25, z: -4.7, w: 1.6, h: 1.6 });
      break;
    }
    case "firehose_cutaway": {
      // Shot 16: You see, 200 ft down, ocean pushes in like a firehose
      put(1, CAPTAIN, "cap", -0.5, D0, 11.5, { mode: "march", phase: ph, expr: t < mid ? "pained" : "shock", tilt: -10 });
      out.fx.push({ key: `arrow16_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxPressureArrow(p, q(uShot, 15)), x: 1.6, y: D0 + 2.0, z: 11.0, w: 1.4, h: 1.4 });
      out.fx.push({ key: `jet16_${q(uShot, 15)}`, cw: 800, ch: 800, draw: (p) => fxSplash(p, q(uShot, 15)), x: 0.4, y: D0 + 1.8, z: 11.2, w: 2.3, h: 2.3 });
      break;
    }
    case "airlock_top": {
      // Shot 17: Golden diagram - Two-door airlock: close top valve
      put(3, SPECIALIST, "spc", -0.65, D0, -5.0, { mode: "stroll", phase: ph, expr: t < mid ? "stern" : "neutral", wave: wv, facing: 1 });
      designCard(out, cam, "airlock17", (p) => fxValveDiagram(p, 1), 0.25, D0, -4.7, 0.85, 0, 0.1, 0.15);
      out.fx.push({ key: `ring17_${q(uShot, 15)}`, cw: 600, ch: 600, draw: (p) => fxRing(p, q(uShot, 15)), x: 0.25, y: D0 + 1.7, z: -4.5, w: 0.9, h: 0.9 });
      break;
    }
    case "airlock_bottom": {
      // Shot 18: Pump in air, then open bottom valve
      put(3, SPECIALIST, "spc", -0.65, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "neutral" : "smile", prop: ["hammer", q(uShot, 15)], facing: 1 });
      designCard(out, cam, "airlock18", (p) => fxValveDiagram(p, 2), 0.25, D0, -4.7, 0.85, 0, 0.1, 0.15);
      out.fx.push({ key: `puff18_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxPuff(p, q(uShot, 15)), x: 0.25, y: D0 + 1.2, z: -4.5, w: 1.0, h: 1.0, soft: true });
      break;
    }
    case "soda_analogy": {
      // Shot 19: Ever opened a shaken soda bottle? (Mess table set at KITCHEN)
      const K = KITCHEN;
      put(2, SAILOR, "sal", K[0] - 0.55, D0, K[2] + 0.4, { mode: "march", phase: ph, expr: t < mid ? "grin" : "shock", wave: 1.0, facing: 1 });
      designCard(out, cam, `soda19_${q(uShot, 12)}`, (p) => fxSodaBottle(p, t), K[0] + 0.2, D0 + 0.35, K[2] - 0.1, 0.8, 0, 0, 0.12);
      out.fx.push({ key: `stars19_${q(uShot, 15)}`, cw: 420, ch: 210, draw: (p) => fxStars(p, q(uShot, 15)), x: K[0] + 0.2, y: D0 + 2.05, z: K[2] - 0.2, w: 0.9, h: 0.45 });
      break;
    }
    case "battery_grate": {
      // Shot 20: Giant lead-acid batteries sit right beneath the floor
      put(4, ENGINEER, "eng", -0.6, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "neutral" : "shock", wave: 0.8, facing: 1 });
      out.fx.push({ key: `splash20_${q(uShot, 15)}`, cw: 800, ch: 800, draw: (p) => fxSplash(p, q(uShot, 15)), x: 0.3, y: D0 + 1.8, z: -4.8, w: 1.5, h: 1.5 });
      out.fx.push({ key: `spark20_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#7ad0ff", 10, 35, 190), x: 0.3, y: D0 + 1.1, z: -4.7, w: 1.0, h: 1.0 });
      break;
    }
    case "chlorine_boil": {
      // Shot 21: Salty water hits batteries -> cooks up deadly chlorine gas
      put(4, ENGINEER, "eng", -0.55, D0, -5.0, { mode: "march", phase: ph, expr: t < mid ? "shock" : "pained", tilt: -10, wave: wv, facing: 1 });
      out.fx.push({ key: `chlor21a_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxChlorineCloud(p, q(uShot, 15)), x: 0.2, y: D0 + 1.35, z: -4.7, w: 1.35, h: 1.35, soft: true });
      out.fx.push({ key: `chlor21b_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxChlorineCloud(p, q((uShot + 0.4) % 1, 15)), x: -0.2, y: D0 + 1.85, z: -4.6, w: 1.5, h: 1.5, soft: true });
      out.fx.push({ key: `burst21_${q(uShot, 15)}`, cw: 500, ch: 500, draw: (p) => fxBurst(p, q(uShot, 15), "#5ee868", 12, 40, 210), x: 0.35, y: D0 + 1.0, z: -4.8, w: 1.1, h: 1.1 });
      break;
    }
    case "gas_pov": {
      // Shot 22: POV handheld - Green gas fills hull and forces submarine up
      put(1, CAPTAIN, "cap", -0.55, D0, -5.2, { mode: "march", phase: ph, expr: t < mid ? "pained" : "stern", wave: 1.0, facing: 1 });
      put(2, SAILOR, "sal", 0.65, D0, -5.4, { mode: "march", phase: ph, expr: t < mid ? "shock" : "pained", lift: 90, facing: -1 });
      out.fx.push({ key: `chlor22_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxChlorineCloud(p, q(uShot, 15)), x: 0.0, y: D0 + 1.6, z: -4.8, w: 1.8, h: 1.8, soft: true });
      out.fx.push({ key: "excl22", cw: 300, ch: 300, draw: (p) => fxExclamation(p, "#ff4438", false), x: -0.55, y: D0 + 2.25, z: -5.0, w: 0.65, h: 0.65 });
      break;
    }
    case "surface_sinking": {
      // Shot 23: Payoff wide - U-1206 surfaces under British bombers; survivors bob in rubber rafts as warship sinks
      put(1, CAPTAIN, "cap", -1.4, D0 + 0.25, -4.2, { mode: "sit", phase: ph, expr: t < mid ? "shock" : "dazed", headTilt: -8 }, [mid], 0.95, false);
      put(3, SPECIALIST, "spc", -0.2, D0 + 0.25, -4.0, { mode: "sit", phase: ph, expr: t < mid ? "pained" : "relief", wave: wv }, [mid], 0.95, false);
      put(2, SAILOR, "sal", 1.3, D0 + 0.25, -4.4, { mode: "sit", phase: ph, expr: t < mid ? "shock" : "relief_open", wave: 1.0 }, [mid], 0.95, false);
      // Green chlorine smoke pouring from the sinking U-boat conning tower hatch
      out.fx.push({ key: `chlor23_${q(uShot, 15)}`, cw: 300, ch: 300, draw: (p) => fxChlorineCloud(p, q(uShot, 15)), x: 0.0, y: D0 + 3.8, z: 11.5, w: 2.6, h: 2.6, soft: true });
      out.fx.push({ key: `ring23a_${q(uShot, 15)}`, cw: 600, ch: 600, draw: (p) => fxRing(p, q(uShot, 15)), x: -0.8, y: D0 + 0.1, z: -4.2, w: 3.8, h: 3.8, flat: true });
      out.fx.push({ key: `ring23b_${q(uShot, 15)}`, cw: 600, ch: 600, draw: (p) => fxRing(p, q((uShot + 0.5) % 1, 15)), x: 0.0, y: D0 + 0.1, z: 12.0, w: 8.5, h: 8.5, flat: true });
      break;
    }
  }

  return out;
};

export { FPS };